export default function Rides() {
  const rides = [
    {
      id: 1,
      title: "Beginner Trail",
      price: "$50/Day",
      image: "/beginner-dirt-bike-trail.jpg",
    },
    {
      id: 2,
      title: "Intermediate Ridge",
      price: "$75/Day",
      image: "/intermediate-mountain-trail.jpg",
    },
    {
      id: 3,
      title: "Expert Challenge",
      price: "$100/Day",
      image: "/expert-extreme-bike-trail.jpg",
    },
    {
      id: 4,
      title: "Dual Package",
      price: "$120/Day",
      image: "/two-riders-adventure.jpg",
    },
    {
      id: 5,
      title: "Trail Package",
      price: "$150/Day",
      image: "/group-trail-riding.jpg",
    },
    {
      id: 6,
      title: "Trail Package",
      price: "$200/Day",
      image: "/premium-trail-experience.jpg",
    },
  ]

  return (
    <section className="bg-slate-900 py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-4xl md:text-5xl font-bold text-white text-center mb-16">
          CHOOSE YOUR <span className="text-orange-500">RIDES</span>
        </h2>

        <div className="grid md:grid-cols-3 gap-8 mb-12">
          {rides.map((ride) => (
            <div
              key={ride.id}
              className="bg-slate-800 rounded overflow-hidden hover:transform hover:scale-105 transition"
            >
              <img src={ride.image || "/placeholder.svg"} alt={ride.title} className="w-full h-48 object-cover" />
              <div className="p-6">
                <h3 className="text-white font-bold text-lg mb-2">{ride.title}</h3>
                <p className="text-gray-400 mb-4">{ride.price}</p>
                <button className="bg-orange-500 hover:bg-orange-600 text-white px-4 py-2 rounded font-bold w-full transition">
                  BOOK NOW
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center">
          <button className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-3 rounded font-bold transition">
            VIEW ALL PACKAGES
          </button>
        </div>
      </div>
    </section>
  )
}
