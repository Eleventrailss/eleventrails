export default function Team() {
  return (
    <section className="bg-white py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-4xl md:text-5xl font-bold text-slate-950 text-center mb-16">
          MEET OUR <span className="text-orange-500">TEAM</span>
        </h2>

        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="grid grid-cols-2 gap-4">
            <img src="/professional-bike-rider.jpg" alt="Team member 1" className="w-full h-64 object-cover rounded" />
            <img src="/adventure-guide.jpg" alt="Team member 2" className="w-full h-64 object-cover rounded" />
            <img
              src="/placeholder.svg?height=300&width=300"
              alt="Team member 3"
              className="w-full h-64 object-cover rounded"
            />
            <img
              src="/placeholder.svg?height=300&width=300"
              alt="Team member 4"
              className="w-full h-64 object-cover rounded"
            />
          </div>
          <div>
            <p className="text-gray-600 text-lg leading-relaxed mb-6">
              Our team consists of experienced riders and adventure guides with over 50 years of combined experience in
              extreme sports and trail riding. We're passionate about sharing the thrill of off-road adventures while
              ensuring safety and creating unforgettable memories.
            </p>
            <p className="text-gray-600 text-lg leading-relaxed">
              Each team member is certified, trained, and dedicated to providing the best possible experience for our
              guests. We believe in pushing limits responsibly and helping riders of all levels achieve their goals.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
