export default function CTA() {
  return (
    <section className="bg-orange-500 py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center gap-8">
          <h2 className="text-4xl md:text-5xl font-bold text-white">
            PLAN YOUR <span className="text-slate-950">RIDE</span>
          </h2>
          <button className="bg-white hover:bg-gray-100 text-orange-500 px-8 py-3 rounded font-bold text-lg transition">
            BOOK NOW
          </button>
        </div>
      </div>
    </section>
  )
}
