export default function Explore() {
  return (
    <section className="bg-white py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
          <div>
            <h2 className="text-4xl md:text-5xl font-bold text-slate-950 mb-6">
              EXPLORE THE
              <br />
              <span className="text-orange-500">EARTH</span> EDGE
            </h2>
            <p className="text-gray-600 text-lg mb-6">
              Discover breathtaking landscapes and challenging trails that will test your skills and push your limits.
              Our carefully curated routes take you through the most scenic and thrilling terrain.
            </p>
            <button className="bg-orange-500 hover:bg-orange-600 text-white px-6 py-2 rounded font-bold transition">
              LEARN MORE
            </button>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <img src="/dirt-bike-trail-landscape.jpg" alt="Trail 1" className="w-full h-64 object-cover rounded" />
            <img src="/mountain-bike-rider.jpg" alt="Trail 2" className="w-full h-64 object-cover rounded" />
            <img src="/off-road-motorcycle.jpg" alt="Trail 3" className="w-full h-64 object-cover rounded" />
            <img src="/extreme-bike-riding.jpg" alt="Trail 4" className="w-full h-64 object-cover rounded" />
          </div>
        </div>
      </div>
    </section>
  )
}
