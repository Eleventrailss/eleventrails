"use client"

import { useState } from "react"
import { Menu, X } from "lucide-react"

export default function Header() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <header className="bg-slate-950 border-b border-slate-800 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-orange-500 rounded-full"></div>
            <span className="text-white font-bold text-xl">ElevenTrails</span>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex gap-8">
            <a href="#" className="text-gray-300 hover:text-white transition">
              Home
            </a>
            <a href="#" className="text-gray-300 hover:text-white transition">
              About
            </a>
            <a href="#" className="text-gray-300 hover:text-white transition">
              Rides
            </a>
            <a href="#" className="text-gray-300 hover:text-white transition">
              FAQ
            </a>
          </nav>

          <div className="hidden md:block">
            <button className="bg-orange-500 hover:bg-orange-600 text-white px-6 py-2 rounded font-semibold transition">
              Book Now
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button className="md:hidden" onClick={() => setIsOpen(!isOpen)}>
            {isOpen ? <X className="text-white" /> : <Menu className="text-white" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <nav className="md:hidden pb-4 flex flex-col gap-4">
            <a href="#" className="text-gray-300 hover:text-white">
              Home
            </a>
            <a href="#" className="text-gray-300 hover:text-white">
              About
            </a>
            <a href="#" className="text-gray-300 hover:text-white">
              Rides
            </a>
            <a href="#" className="text-gray-300 hover:text-white">
              FAQ
            </a>
            <button className="bg-orange-500 text-white px-6 py-2 rounded font-semibold w-full">Book Now</button>
          </nav>
        )}
      </div>
    </header>
  )
}
