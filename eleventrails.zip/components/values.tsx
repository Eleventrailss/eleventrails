export default function Values() {
  const values = [
    { title: "Safety", image: "/placeholder.svg?height=300&width=300" },
    { title: "Excellence", image: "/placeholder.svg?height=300&width=300" },
    { title: "Adventure", image: "/placeholder.svg?height=300&width=300" },
    { title: "Community", image: "/placeholder.svg?height=300&width=300" },
  ]

  return (
    <section className="bg-slate-950 py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-4xl md:text-5xl font-bold text-white text-center mb-16">
          RIDES <span className="text-orange-500">CORE</span> VALUE
        </h2>

        <div className="grid md:grid-cols-4 gap-8">
          {values.map((value, index) => (
            <div key={index} className="text-center">
              <img
                src={value.image || "/placeholder.svg"}
                alt={value.title}
                className="w-full h-64 object-cover rounded mb-4"
              />
              <h3 className="text-white font-bold text-xl">{value.title}</h3>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
