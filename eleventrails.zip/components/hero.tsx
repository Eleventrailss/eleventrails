export default function Hero() {
  return (
    <section className="relative h-screen bg-slate-950 overflow-hidden">
      <div className="absolute inset-0">
        <img src="/dirt-bike-rider-on-mountain-trail.jpg" alt="Dirt bike rider" className="w-full h-full object-cover opacity-60" />
        <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-950/50 to-transparent"></div>
      </div>

      <div className="relative h-full flex items-center">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
          <div className="max-w-2xl">
            <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 leading-tight">
              UNLEASH THE
              <br />
              <span className="text-orange-500">THRILL</span> OF THE
              <br />
              OPEN ROAD
            </h1>
            <p className="text-gray-300 text-lg mb-8 max-w-xl">
              Experience the ultimate dirt bike adventure across stunning trails and challenging terrain.
            </p>
            <button className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-3 rounded font-bold text-lg transition">
              EXPLORE NOW
            </button>
          </div>
        </div>
      </div>
    </section>
  )
}
