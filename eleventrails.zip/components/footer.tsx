export default function Footer() {
  return (
    <footer className="bg-slate-950 border-t border-slate-800 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8 mb-12">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-6 h-6 bg-orange-500 rounded-full"></div>
              <span className="text-white font-bold">ElevenTrails</span>
            </div>
            <p className="text-gray-400 text-sm">
              Your ultimate adventure destination for dirt bike trails and extreme sports.
            </p>
          </div>

          <div>
            <h4 className="text-white font-bold mb-4">Quick Link</h4>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition">
                  Home
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition">
                  About
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition">
                  Rides
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition">
                  Contact
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-4">Help</h4>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition">
                  FAQ
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition">
                  Support
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition">
                  Booking
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition">
                  Safety
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-4">Get In Touch</h4>
            <p className="text-gray-400 text-sm mb-2">📞 +1 (555) 123-4567</p>
            <p className="text-gray-400 text-sm mb-4">✉️ info@eleventrails.com</p>
            <div className="flex gap-4">
              <a href="#" className="text-gray-400 hover:text-orange-500 transition">
                f
              </a>
              <a href="#" className="text-gray-400 hover:text-orange-500 transition">
                t
              </a>
              <a href="#" className="text-gray-400 hover:text-orange-500 transition">
                ig
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-slate-800 pt-8 text-center text-gray-400 text-sm">
          <p>&copy; 2025 ElevenTrails. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}
