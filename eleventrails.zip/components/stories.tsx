export default function Stories() {
  return (
    <section className="bg-cyan-600 py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              TALES FROM
              <br />
              <span className="text-orange-500">LOMBOK</span> TRAILS
            </h2>
            <p className="text-white text-lg leading-relaxed mb-6">
              Experience the legendary trails of Lombok, where adventure meets natural beauty. Our riders have conquered
              some of the most challenging and scenic routes in the region, creating stories that will inspire your next
              adventure.
            </p>
            <button className="bg-orange-500 hover:bg-orange-600 text-white px-6 py-2 rounded font-bold transition">
              READ STORIES
            </button>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <img
              src="/placeholder.svg?height=300&width=300"
              alt="Story 1"
              className="w-full h-64 object-cover rounded col-span-2"
            />
            <img
              src="/placeholder.svg?height=300&width=300"
              alt="Story 2"
              className="w-full h-32 object-cover rounded"
            />
            <img
              src="/placeholder.svg?height=300&width=300"
              alt="Story 3"
              className="w-full h-32 object-cover rounded"
            />
          </div>
        </div>
      </div>
    </section>
  )
}
