export default function Gear() {
  return (
    <section className="bg-slate-950 py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              GEAR UP FOR
              <br />
              THE <span className="text-orange-500">ADVENTURE</span>
            </h2>
            <p className="text-gray-300 text-lg mb-6">
              We provide top-quality protective gear and equipment to ensure your safety and comfort on every ride. From
              helmets to protective suits, we've got everything you need.
            </p>
            <button className="bg-orange-500 hover:bg-orange-600 text-white px-6 py-2 rounded font-bold transition">
              VIEW GEAR
            </button>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <img src="/motorcycle-helmet-protective-gear.jpg" alt="Gear 1" className="w-full h-64 object-cover rounded" />
            <img src="/dirt-bike-protective-suit.jpg" alt="Gear 2" className="w-full h-64 object-cover rounded" />
            <img src="/motorcycle-gloves-boots.jpg" alt="Gear 3" className="w-full h-64 object-cover rounded" />
            <img src="/rider-equipment-accessories.jpg" alt="Gear 4" className="w-full h-64 object-cover rounded" />
          </div>
        </div>
      </div>
    </section>
  )
}
