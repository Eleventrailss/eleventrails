import Header from "@/components/header"
import Hero from "@/components/hero"
import Explore from "@/components/explore"
import Gear from "@/components/gear"
import Rides from "@/components/rides"
import Team from "@/components/team"
import Testimonials from "@/components/testimonials"
import Stories from "@/components/stories"
import Values from "@/components/values"
import CTA from "@/components/cta"
import Footer from "@/components/footer"

export default function Home() {
  return (
    <main className="bg-slate-950">
      <Header />
      <Hero />
      <Explore />
      <Gear />
      <Rides />
      <Team />
      <Testimonials />
      <Stories />
      <Values />
      <CTA />
      <Footer />
    </main>
  )
}
